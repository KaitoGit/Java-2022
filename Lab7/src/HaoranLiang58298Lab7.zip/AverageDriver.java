public class AverageDriver {
    public static void main(String args[])

    {

        /* Object for the class */

        Average averageObj = new Average();

        /* Object call the toString function */

        System.out.println(averageObj.toString());

    }
}
